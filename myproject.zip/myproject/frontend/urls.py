from django.contrib import admin
from .import views
from django.urls import path

urlpatterns = [
    path('mainlogin',views.mainlogin,name = 'mainlogin'),
    path('userlogin/',views.userlogin,name = 'userlogin'),
    path('index/',views.index,name = 'index'),
    path('',views.home,name = 'home'),
    path('admin/',views.admin,name = 'admin'),
    path('diff/',views.diff, name = 'diff'),
    path('wwwdiff/',views.wwwdiff, name = 'wwwdiff'),
    path('Pythonmod/',views.Pythonmod, name = 'Pythonmod'),
    path('Djangocommands/',views.Djangocommands, name = 'Djangocommands'),
    path('cart/',views.cart, name = 'cart'),
]