from django.shortcuts import render
from django.http import HttpResponse

def mainlogin(requests):
    return render(requests,'mainlogin.html')

def userlogin(requests):
    return render(requests,'userlogin.html')

def index(requests):
    return render(requests,"index.html")

def home(requests):
    return render(requests,"home.html")

def admin(requests):
    return render(requests,'admin.html')

def diff(requests):
    return render(requests,'diff.html')

def wwwdiff(requests):
    return render(requests,'wwwdiff.html')

def Pythonmod(requests):
    return render(requests,'Pythonmod.html')

def Djangocommands(requests):
    return render(requests,'Djangocommands.html')

def cart(requests):
    return render(requests,'cart.html')